document.addEventListener('DOMContentLoaded', () => {
	const relatedProductsUl = document.querySelector('.related-products');
	if (!relatedProductsUl) return;

	/**
	 * Выравнивает высоту только для внешнего слайдера, выбирая прямых детей.
	 */
	const equalizeOuterSlideHeights = () => {
		const $outerSlider = $('.related-products-carousel');
		if (!$outerSlider.length) return;
		// Ищем все li внутри слайдера, исключая slick-клоны
		const $outerSlides = $outerSlider.find('li.related-products__item:not(.slick-cloned)');
		$outerSlides.css('height', 'auto');
		let maxHeight = 0;
		$outerSlides.each(function () {
			const h = $(this).outerHeight();
			if (h > maxHeight) {
				maxHeight = h;
			}
		});
		$outerSlides.css('height', maxHeight + 'px');
	};


	/**
	 * Инициализация слайдера для изображений внутри карточки.
	 * Если слайдов меньше или равно одному – инициализация не производится.
	 */
	const initSlider = (element) => {
		let slides = $(element).find('.image-item');
		if (!slides.length) {
			slides = $(element).children();
		}
		if (slides.length <= 1) return;

		if (!$(element).hasClass('slick-initialized')) {
			$(element).slick({
				slidesToShow: 1,
				slidesToScroll: 1,
				lazyLoad: 'ondemand',
				infinite: false,
				arrows: true,
				dots: true,
				prevArrow: '<button type="button" class="slick-prev"><svg width="16" height="16" style="transform: rotate(-180deg)" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
					'    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.46967 5.46967C9.76256 5.17678 10.2374 5.17678 10.5303 5.46967L16.5303 11.4697C16.8232 11.7626 16.8232 12.2374 16.5303 12.5303L10.5303 18.5303C10.2374 18.8232 9.76256 18.8232 9.46967 18.5303C9.17678 18.2374 9.17678 17.7626 9.46967 17.4697L14.9393 12L9.46967 6.53033C9.17678 6.23744 9.17678 5.76256 9.46967 5.46967Z" fill="#D83D0E"></path>\n' +
					'</svg></button>',
				nextArrow: '<button type="button" class="slick-next"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
					'    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.46967 5.46967C9.76256 5.17678 10.2374 5.17678 10.5303 5.46967L16.5303 11.4697C16.8232 11.7626 16.8232 12.2374 16.5303 12.5303L10.5303 18.5303C10.2374 18.8232 9.76256 18.8232 9.46967 18.5303C9.17678 18.2374 9.17678 17.7626 9.46967 17.4697L14.9393 12L9.46967 6.53033C9.17678 6.23744 9.17678 5.76256 9.46967 5.46967Z" fill="#D83D0E"></path>\n' +
					'</svg></button>',
				responsive: [
					{
						breakpoint: 768,
						settings: {
							slidesToShow: 1
						}
					}
				]
			});

			$(element)
				.find('img.lazy-load')
				.each(function () {
					const img = $(this);
					if (img) {
						img.attr('src', img.data('src'));
						img.removeClass('lazy-load');
						img.css({
							opacity: '1',
							visibility: 'visible',
						});
					}
				});
		}
	};

	/**
	 * Настройка IntersectionObserver для ленивой инициализации внутренних слайдеров.
	 */
	const setupIntersectionObserver = () => {
		const observer = new IntersectionObserver(
			(entries, observer) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						initSlider(entry.target);
						observer.unobserve(entry.target);
					}
				});
			},
			{ threshold: 0.5 }
		);

		$('.image-wrap').each(function () {
			if ($(this).length > 0) {
				observer.observe(this);
			}
		});
	};

	/**
	 * Инициализирует внешний слайдер-карусель для связанных продуктов
	 * и вызывает выравнивание высот только для его слайдов.
	 */
	const setupCarousel = () => {
		const relatedProductsOptions = {
			infinite: false,
			slidesToShow: 4,
			slidesToScroll: 1,
			prevArrow: $('.slick-prev'),
			nextArrow: $('.slick-next'),
			arrows: true,
			dots: false,
			draggable: false,
		};

		if (window.matchMedia('(min-width: 990px)').matches) {
			$('.related-products-carousel').slick(relatedProductsOptions);

			$('.related-products-carousel').on('afterChange', function (event, slick, currentSlide) {
				const $prev = $('.slick-prev');
				const $next = $('.slick-next');

				if (currentSlide !== 0) {
					$prev.removeClass('slick-disabled');
				}
				if (currentSlide === slick.slideCount - slick.options.slidesToShow) {
					$next.addClass('slick-disabled');
				} else {
					$next.removeClass('slick-disabled');
				}
				// Выравниваем высоту только внешнего слайдера
				equalizeOuterSlideHeights();
			});

			// Выравниваем сразу после инициализации
			equalizeOuterSlideHeights();
		}

		window.addEventListener('resize', () => {
			if (window.matchMedia('(min-width: 990px)').matches) {
				if (!$('.related-products-carousel').hasClass('slick-initialized')) {
					$('.related-products-carousel').slick(relatedProductsOptions);
					$('.related-products > ul').on('afterChange', function (event, slick, currentSlide) {
						const $prev = $('.slick-prev');
						const $next = $('.slick-next');

						if (currentSlide !== 0) {
							$prev.removeClass('slick-disabled');
						}
						if (currentSlide === slick.slideCount - slick.options.slidesToShow) {
							$next.addClass('slick-disabled');
						} else {
							$next.removeClass('slick-disabled');
						}
						equalizeOuterSlideHeights();
					});
				}
				equalizeOuterSlideHeights();
			} else {
				if ($('.related-products-carousel').hasClass('slick-initialized')) {
					$('.related-products-carousel').slick('unslick');
				}
			}
		});
	};

	const mutationCallback = (mutationsList) => {
		mutationsList.forEach((mutation) => {
			if (mutation.type === 'childList') {
				setupIntersectionObserver();
				setupCarousel();
			}
		});
	};

	const observerConfig = {
		childList: true,
		attributes: false,
		subtree: false,
	};

	const mutationObserver = new MutationObserver(mutationCallback);
	mutationObserver.observe(relatedProductsUl, observerConfig);
});
